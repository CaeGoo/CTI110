<script>start("/Users/trulykato/CTI110/P4LAB1_GoodenCaelon.py/");</script>
<script>onHasParentDirectory();</script>
<script>addRow("P4LAB1A_GoodenCaelon.py","P4LAB1A_GoodenCaelon.py",0,538,"538 B",1744228988,"4/9/25, 4:03:08 PM");</script>
<script>addRow("P4LAB1B_GoodenCaelon.py","P4LAB1B_GoodenCaelon.py",0,852,"852 B",1744233947,"4/9/25, 5:25:47 PM");</script>
